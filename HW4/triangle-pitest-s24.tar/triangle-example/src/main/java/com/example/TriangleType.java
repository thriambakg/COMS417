package com.example;

public enum TriangleType {
  INVALID, SCALENE, EQUILATERAL, ISOSCELES
}
