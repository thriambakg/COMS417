# Mutation testing example

This is a very simple example of a project configured to for mutation testing with pitest.

Pitest has been bound to maven's verify goal, so mutation testing will be triggered whenever 

```
mvn verify
```

Is run.

## Pitest version

This project is configured to use the latest snapshot version of pitest (i.e the unstable development version).
