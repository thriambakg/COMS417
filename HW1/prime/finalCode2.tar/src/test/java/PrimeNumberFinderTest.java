import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays; 

/*sample tests for homework. you will need to add to these */

public class PrimeNumberFinderTest{

    //Instantiate class - this will cover the constructor of the class
    @Test
    public void instantiateClass(){
      PrimeNumberFinder myPrime=new PrimeNumberFinder();
    }

    
    //Tests for the findPrimes method (you can add to these)
    @Test
    public void testFindPrimes1() {
       List<Integer> primes = PrimeNumberFinder.findPrimes(2,8);
       List<Integer> expected = Arrays.asList(2,3,5,7);
       assertArrayEquals(expected.toArray(),primes.toArray());
    }
   @Test
   public void testFindPrimes2() {
       List<Integer> primes = PrimeNumberFinder.findPrimes(10,21);
       List<Integer> expected = Arrays.asList(11,13,17,19);
       assertArrayEquals(expected.toArray(),primes.toArray());
    }

   @Test
   public void testFindPrimes3() {
	List<Integer> primes = PrimeNumberFinder.findPrimes(3,1);
	List<Integer> expected = Arrays.asList(2,3);
        assertArrayEquals(expected.toArray(),primes.toArray());
   }

    //tests for the isPrime method

    //test for a prime number
   @Test
    public void testIsPrime1() {
        assertTrue(PrimeNumberFinder.isPrime(23));
    }

    //test for a non-prime number
    @Test
    public void testIsPrime2() {
        assertFalse(PrimeNumberFinder.isPrime(10));
    }

    //test for a number less than one covering first if statement
    @Test
    public void testLessThanOne() {
	assertFalse(PrimeNumberFinder.isPrime(-1));
    }

    //test for a number divisible by 5 covering first segment of line 77
    @Test
    public void testDivByFive() {
	assertFalse(PrimeNumberFinder.isPrime(25));
    }
    //test for a number 2 covering second if statement
    @Test
    public void testTwo() {
	assertTrue(PrimeNumberFinder.isPrime(2));
    }
    //continuing coverage of second if statement, 3
    @Test
    public void testThree() {
	assertTrue(PrimeNumberFinder.isPrime(3));
    }
    //final coverage of second if statement, 9
    @Test
    public void testNine() {
	assertFalse(PrimeNumberFinder.isPrime(9));
    }
    // covering third if statement, divisible by 2
    @Test
    public void testdivBytwo() {
	assertFalse(PrimeNumberFinder.isPrime(4));
    }
    //covering third if statement's last two statements, div by 6 and by proxy 3
    @Test
    public void testDivBythree() {
	assertFalse(PrimeNumberFinder.isPrime(6));
    }
    //covering line 77, a number divisible by 7
    @Test
    public void testdivbySeven() {
	assertFalse(PrimeNumberFinder.isPrime(49));
    }
    //covering line 77, running the loop as well as a number divisibly by 11
    @Test
    public void divByeleven() {
	assertFalse(PrimeNumberFinder.isPrime(121));
    }

    @Test
    public void fault1() {
	assertFalse(PrimeNumberFinder.isPrime(1));
    }

    @Test
    public void thirteen() {
	assertTrue(PrimeNumberFinder.isPrime(13));
    }

    @Test
    public void eleven() {
	assertTrue(PrimeNumberFinder.isPrime(11));
    }

    @Test
    public void seventeen() {
	assertTrue(PrimeNumberFinder.isPrime(17));
    }

    @Test
    public void nineteen() {
	assertTrue(PrimeNumberFinder.isPrime(19));
    }
    @Test
    public void twentythree() {
	assertTrue(PrimeNumberFinder.isPrime(23));
    }

    @Test
    public void twentynine() {
	assertTrue(PrimeNumberFinder.isPrime(29));
    }
    

    //tests for the sumofP method - note the list provided is the list of primes
    // to be summed - not the lower and upper bound

    @Test
    public void sumofP1() {
	List<Integer> input = Arrays.asList(5,7);
	assertEquals(12,PrimeNumberFinder.computeSumOfPrimes(input));
    }
 
    @Test
    public void listsizeSmall() {
	List<Integer> input = Arrays.asList(5);
	assertEquals(5,PrimeNumberFinder.computeSumOfPrimes(input));
    }

    @Test
    public void listsizezero() {
	List<Integer> input = Arrays.asList();
	assertEquals(0,PrimeNumberFinder.computeSumOfPrimes(input));
	}
}
